package edu.sdsc.awesome.neo4j.awsmneo4jclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsmNeo4jClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsmNeo4jClientApplication.class, args);
	}
}
